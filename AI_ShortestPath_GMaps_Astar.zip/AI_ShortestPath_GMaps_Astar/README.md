# AI_ShortestPath_GMaps_Astar
a program to find out an optimal route from RGIA airport to BITS Hyderabad other than the ones given in the map.



>Instructions 
>

>a.create a virtual environment and install osmnx in it using conda:-
>

>execute within the directory :
>

>`  python -m venv ./AI_ShortestRoute_Gmaps_Astar `
>

>b.install dependencies :-
>

>` pip install -r requirements.txt ` 
>

>(not yet set up by me , do this later)
  
    
